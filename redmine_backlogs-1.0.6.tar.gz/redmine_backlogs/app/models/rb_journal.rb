class RbJournal < ActiveRecord::Base
  unloadable
end
